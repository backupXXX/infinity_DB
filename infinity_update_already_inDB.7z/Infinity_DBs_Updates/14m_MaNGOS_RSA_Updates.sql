-- Drakkari Skullcrusher
UPDATE `creature_template` SET `VehicleId` = 744 WHERE `entry` = 28844;
-- rsa ICC corrects
UPDATE `creature_template` SET `VehicleId` = 639, `AIName`='', `PowerType` = 3 WHERE `entry` IN (38402,38582,38583);

DELETE FROM `spell_proc_event` WHERE entry IN (70871); 
INSERT INTO `spell_proc_event` VALUES 
(70871, 0x7F,  0, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0.000000, 0.000000, 0); 

--- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r13 r14 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r14');

UPDATE db_version SET `cache_id`= 'r14';
UPDATE db_version SET `version`= 'YTDB576_Infinity_Update_r14';