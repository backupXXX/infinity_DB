-- Argent Cannon (quest 13086)
UPDATE `creature_template` SET
    spell1 = 57485,
    spell2 = 57412,
    spell3 = 0,
    spell4 = 0,
    spell5 = 0,
    spell6 = 0,
    VehicleId = 244
WHERE `entry` IN (30236);

DELETE FROM `npc_spellclick_spells` WHERE npc_entry IN (30236);
INSERT INTO `npc_spellclick_spells` VALUES
(30236, 57573, 13086, 1, 13086, 1);

-- Wyrmrest Vanquisher (quest 12498)
UPDATE `creature_template` SET
    spell1 = 55987,
    spell2 = 50348,
    spell3 = 50430,
    spell4 = 0,
    spell5 = 0,
    spell6 = 0,
    VehicleId = 99
WHERE `entry` IN (27996);

DELETE FROM `npc_spellclick_spells` WHERE npc_entry IN (27996);
INSERT INTO `npc_spellclick_spells` VALUES
(27996, 50343, 12498, 1, 12498, 1);

REPLACE INTO `creature_template_addon` (entry, auras) VALUES (27996, '53112 0 53112 1 53112 2');

-- from me
-- Quest Reclamation (12546)
UPDATE `creature_template` SET `spell1` = 50978,`spell2` = 50980,`spell3` = 50983,`spell4` = 50985,
`VehicleId` = 111
WHERE  `entry` = 28222;

-- from YTDB/TC 578
DELETE FROM `npc_spellclick_spells` WHERE `npc_entry` IN (27850,27881,28094,28312,28319,28670,32627,32629);
INSERT INTO `npc_spellclick_spells` (`npc_entry`, `spell_id`, `quest_start`, `quest_start_active`, `quest_end`, `cast_flags`) VALUES
(27850, 60968, 0, 0, 0, 1),
(27881, 60968, 0, 0, 0, 1),
(28094, 60968, 0, 0, 0, 1),
(28312, 60968, 0, 0, 0, 1),
(28319, 60968, 0, 0, 0, 1),
(28670, 52196, 0, 0, 0, 1),
(32627, 60968, 0, 0, 0, 1),
(32629, 60968, 0, 0, 0, 1);

UPDATE `creature_template` SET `VehicleId` = 774 WHERE `entry` = 28844;
-- ICC
UPDATE `creature_template` SET `vehicleId` = 532 WHERE `entry` IN (36609,39120,39121,39122);

-- from YTDB/TC 570
UPDATE `creature_template` SET `VehicleId` = 51  WHERE  `entry` = 27409;
UPDATE `creature_template` SET `VehicleId` = 107 WHERE  `entry` = 28135;
UPDATE `creature_template` SET `VehicleId` = 206 WHERE  `entry` = 28379;
UPDATE `creature_template` SET `VehicleId` = 121 WHERE  `entry` = 28468;
UPDATE `creature_template` SET `VehicleId` = 492 WHERE  `entry` = 25765;
UPDATE `creature_template` SET `VehicleId` = 25  WHERE  `entry` = 27516;
UPDATE `creature_template` SET `VehicleId` = 156 WHERE  `entry` = 26788;
UPDATE `creature_template` SET `VehicleId` = 129 WHERE  `entry` = 28710;
UPDATE `creature_template` SET `VehicleId` = 25  WHERE  `entry` = 28446;
UPDATE `creature_template` SET `VehicleId` = 22  WHERE  `entry` = 24825;
UPDATE `creature_template` SET `VehicleId` = 22  WHERE  `entry` = 24821;
UPDATE `creature_template` SET `VehicleId` = 22  WHERE  `entry` = 24823;
UPDATE `creature_template` SET `VehicleId` = 22  WHERE  `entry` = 24806;
UPDATE `creature_template` SET `VehicleId` = 200 WHERE  `entry` = 26191;
UPDATE `creature_template` SET `VehicleId` = 113 WHERE  `entry` = 28246;
UPDATE `creature_template` SET `VehicleId` = 156 WHERE  `entry` = 27850;
UPDATE `creature_template` SET `VehicleId` = 156 WHERE  `entry` = 27838;
UPDATE `creature_template` SET `VehicleId` = 30  WHERE  `entry` = 25881;
UPDATE `creature_template` SET `VehicleId` = 156 WHERE  `entry` = 26807;
UPDATE `creature_template` SET `VehicleId` = 34  WHERE  `entry` = 26585;
UPDATE `creature_template` SET `VehicleId` = 39  WHERE  `entry` = 26813;
UPDATE `creature_template` SET `VehicleId` = 127 WHERE  `entry` = 28669;
UPDATE `creature_template` SET `VehicleId` = 203 WHERE  `entry` = 29863;
UPDATE `creature_template` SET `VehicleId` = 200 WHERE  `entry` = 27883;
UPDATE `creature_template` SET `VehicleId` = 111 WHERE  `entry` = 28222;
UPDATE `creature_template` SET `VehicleId` = 115 WHERE  `entry` = 28308;
UPDATE `creature_template` SET `VehicleId` = 191 WHERE  `entry` = 29306;
UPDATE `creature_template` SET `VehicleId` = 176 WHERE  `entry` = 29351;
UPDATE `creature_template` SET `VehicleId` = 177 WHERE  `entry` = 29358;
UPDATE `creature_template` SET `VehicleId` = 165 WHERE  `entry` = 29403;
UPDATE `creature_template` SET `VehicleId` = 169 WHERE  `entry` = 29460;
UPDATE `creature_template` SET `VehicleId` = 173 WHERE  `entry` = 29500;
UPDATE `creature_template` SET `VehicleId` = 175 WHERE  `entry` = 29555;
UPDATE `creature_template` SET `VehicleId` = 179 WHERE  `entry` = 29579;
UPDATE `creature_template` SET `VehicleId` = 181 WHERE  `entry` = 29602;
UPDATE `creature_template` SET `VehicleId` = 183 WHERE  `entry` = 29625;
UPDATE `creature_template` SET `VehicleId` = 186 WHERE  `entry` = 29677;
UPDATE `creature_template` SET `VehicleId` = 198 WHERE  `entry` = 29708;
UPDATE `creature_template` SET `VehicleId` = 194 WHERE  `entry` = 29709;
UPDATE `creature_template` SET `VehicleId` = 243 WHERE  `entry` = 29736;
UPDATE `creature_template` SET `VehicleId` = 197 WHERE  `entry` = 29754;
UPDATE `creature_template` SET `VehicleId` = 201 WHERE  `entry` = 29838;
UPDATE `creature_template` SET `VehicleId` = 205 WHERE  `entry` = 29884;
UPDATE `creature_template` SET `VehicleId` = 209 WHERE  `entry` = 29931;
UPDATE `creature_template` SET `VehicleId` = 214 WHERE  `entry` = 30090;
UPDATE `creature_template` SET `VehicleId` = 217 WHERE  `entry` = 30124;
UPDATE `creature_template` SET `VehicleId` = 219 WHERE  `entry` = 30134;
UPDATE `creature_template` SET `VehicleId` = 221 WHERE  `entry` = 30165;
UPDATE `creature_template` SET `VehicleId` = 227 WHERE  `entry` = 30301;
UPDATE `creature_template` SET `VehicleId` = 25  WHERE  `entry` = 30378;
UPDATE `creature_template` SET `VehicleId` = 316 WHERE  `entry` = 30468;
UPDATE `creature_template` SET `VehicleId` = 252 WHERE  `entry` = 30719;
UPDATE `creature_template` SET `VehicleId` = 259 WHERE  `entry` = 31110;
UPDATE `creature_template` SET `VehicleId` = 265 WHERE  `entry` = 31163;
UPDATE `creature_template` SET `VehicleId` = 265 WHERE  `entry` = 31220;
UPDATE `creature_template` SET `VehicleId` = 265 WHERE  `entry` = 31221;
UPDATE `creature_template` SET `VehicleId` = 269 WHERE  `entry` = 31268;
UPDATE `creature_template` SET `VehicleId` = 268 WHERE  `entry` = 31269;
UPDATE `creature_template` SET `VehicleId` = 273 WHERE  `entry` = 31406;
UPDATE `creature_template` SET `VehicleId` = 277 WHERE  `entry` = 31407;
UPDATE `creature_template` SET `VehicleId` = 274 WHERE  `entry` = 31408;
UPDATE `creature_template` SET `VehicleId` = 278 WHERE  `entry` = 31409;
UPDATE `creature_template` SET `VehicleId` = 282 WHERE  `entry` = 31784;
UPDATE `creature_template` SET `VehicleId` = 282 WHERE  `entry` = 31785;
UPDATE `creature_template` SET `VehicleId` = 736 WHERE  `entry` = 31788;
UPDATE `creature_template` SET `VehicleId` = 512 WHERE  `entry` = 31830;
UPDATE `creature_template` SET `VehicleId` = 287 WHERE  `entry` = 31838;
UPDATE `creature_template` SET `VehicleId` = 291 WHERE  `entry` = 32227;
UPDATE `creature_template` SET `VehicleId` = 300 WHERE  `entry` = 32326;
UPDATE `creature_template` SET `VehicleId` = 301 WHERE  `entry` = 32344;
UPDATE `creature_template` SET `VehicleId` = 302 WHERE  `entry` = 32348;
UPDATE `creature_template` SET `VehicleId` = 273 WHERE  `entry` = 32512;
UPDATE `creature_template` SET `VehicleId` = 369 WHERE  `entry` = 32531;
UPDATE `creature_template` SET `VehicleId` = 40  WHERE  `entry` = 30775;
UPDATE `creature_template` SET `VehicleId` = 201 WHERE  `entry` = 30935;
UPDATE `creature_template` SET `VehicleId` = 209 WHERE  `entry` = 30936;
UPDATE `creature_template` SET `VehicleId` = 191 WHERE  `entry` = 31368;
UPDATE `creature_template` SET `VehicleId` = 108 WHERE  `entry` = 31669;
UPDATE `creature_template` SET `VehicleId` = 380 WHERE  `entry` = 32933;
UPDATE `creature_template` SET `VehicleId` = 342 WHERE  `entry` = 33190;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33297;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33298;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33300;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33301;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33316;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33317;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33318;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33320;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33322;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33323;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33324;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33408;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33409;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33414;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33416;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 33418;
UPDATE `creature_template` SET `VehicleId` = 368 WHERE  `entry` = 33519;
UPDATE `creature_template` SET `VehicleId` = 369 WHERE  `entry` = 33531;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33790;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33791;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33792;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33793;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33794;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33795;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33796;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33798;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33799;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33800;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33842;
UPDATE `creature_template` SET `VehicleId` = 349 WHERE  `entry` = 33843;
UPDATE `creature_template` SET `VehicleId` = 353 WHERE  `entry` = 33885;
UPDATE `creature_template` SET `VehicleId` = 328 WHERE  `entry` = 33909;
UPDATE `creature_template` SET `VehicleId` = 380 WHERE  `entry` = 33910;
UPDATE `creature_template` SET `VehicleId` = 380 WHERE  `entry` = 33911;
UPDATE `creature_template` SET `VehicleId` = 381 WHERE  `entry` = 33955;
UPDATE `creature_template` SET `VehicleId` = 385 WHERE  `entry` = 33984;
UPDATE `creature_template` SET `VehicleId` = 387 WHERE  `entry` = 34003;
UPDATE `creature_template` SET `VehicleId` = 335 WHERE  `entry` = 34045;
UPDATE `creature_template` SET `VehicleId` = 370 WHERE  `entry` = 34106;
UPDATE `creature_template` SET `VehicleId` = 371 WHERE  `entry` = 34108;
UPDATE `creature_template` SET `VehicleId` = 373 WHERE  `entry` = 34109;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 34125;
UPDATE `creature_template` SET `VehicleId` = 397 WHERE  `entry` = 34162;
UPDATE `creature_template` SET `VehicleId` = 399 WHERE  `entry` = 34214;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 36557;
UPDATE `creature_template` SET `VehicleId` = 485 WHERE  `entry` = 35641;
UPDATE `creature_template` SET `VehicleId` = 480 WHERE  `entry` = 35635;
UPDATE `creature_template` SET `VehicleId` = 106 WHERE  `entry` = 34802;
UPDATE `creature_template` SET `VehicleId` = 486 WHERE  `entry` = 36558;
UPDATE `creature_template` SET `VehicleId` = 477 WHERE  `entry` = 36087;
UPDATE `creature_template` SET `VehicleId` = 477 WHERE  `entry` = 36089;
UPDATE `creature_template` SET `VehicleId` = 442 WHERE  `entry` = 35438;
UPDATE `creature_template` SET `VehicleId` = 442 WHERE  `entry` = 35439;
UPDATE `creature_template` SET `VehicleId` = 442 WHERE  `entry` = 35440;
UPDATE `creature_template` SET `VehicleId` = 446 WHERE  `entry` = 35270;
UPDATE `creature_template` SET `VehicleId` = 446 WHERE  `entry` = 35271;
UPDATE `creature_template` SET `VehicleId` = 446 WHERE  `entry` = 35272;
UPDATE `creature_template` SET `VehicleId` = 555 WHERE  `entry` = 36839;
UPDATE `creature_template` SET `VehicleId` = 599 WHERE  `entry` = 37187;
UPDATE `creature_template` SET `VehicleId` = 648 WHERE  `entry` = 38712;
UPDATE `creature_template` SET `VehicleId` = 562 WHERE  `entry` = 37636;
UPDATE `creature_template` SET `VehicleId` = 560 WHERE  `entry` = 37626;
UPDATE `creature_template` SET `VehicleId` = 522 WHERE  `entry` = 37627;
UPDATE `creature_template` SET `VehicleId` = 648 WHERE  `entry` = 38974;
UPDATE `creature_template` SET `VehicleId` = 648 WHERE  `entry` = 38973;
UPDATE `creature_template` SET `VehicleId` = 648 WHERE  `entry` = 38975;
UPDATE `creature_template` SET `VehicleId` = 106 WHERE  `entry` = 35419;
UPDATE `creature_template` SET `VehicleId` = 106 WHERE  `entry` = 35421;
UPDATE `creature_template` SET `VehicleId` = 106 WHERE  `entry` = 35415;
UPDATE `creature_template` SET `VehicleId` = 436 WHERE  `entry` = 36358;
UPDATE `creature_template` SET `VehicleId` = 36  WHERE  `entry` = 35413;
UPDATE `creature_template` SET `VehicleId` = 452 WHERE  `entry` = 35410;
UPDATE `creature_template` SET `VehicleId` = 591 WHERE  `entry` = 38285;
UPDATE `creature_template` SET `VehicleId` = 718 WHERE  `entry` = 40081;
UPDATE `creature_template` SET `VehicleId` = 718 WHERE  `entry` = 40470;
UPDATE `creature_template` SET `VehicleId` = 718 WHERE  `entry` = 40471;
UPDATE `creature_template` SET `VehicleId` = 718 WHERE  `entry` = 40472;
UPDATE `creature_template` SET `VehicleId` = 79  WHERE  `entry` = 35427;
UPDATE `creature_template` SET `VehicleId` = 79  WHERE  `entry` = 35429;
UPDATE `creature_template` SET `VehicleId` = 591 WHERE  `entry` = 38788;
UPDATE `creature_template` SET `VehicleId` = 591 WHERE  `entry` = 38789;
UPDATE `creature_template` SET `VehicleId` = 591 WHERE  `entry` = 38790;
UPDATE `creature_template` SET `VehicleId` = 700 WHERE  `entry` = 39682;
UPDATE `creature_template` SET `VehicleId` = 745 WHERE  `entry` = 39713;
UPDATE `creature_template` SET `VehicleId` = 745 WHERE  `entry` = 39714;
UPDATE `creature_template` SET `VehicleId` = 753 WHERE  `entry` = 39759;
UPDATE `creature_template` SET `VehicleId` = 763 WHERE  `entry` = 39819;
UPDATE `creature_template` SET `VehicleId` = 711 WHERE  `entry` = 39860;
UPDATE `creature_template` SET `VehicleId` = 747 WHERE  `entry` = 40479;
-- YTDB updates 571-578
UPDATE `creature_template` SET `VehicleId` = 265 WHERE  `entry` = 31225;
UPDATE `creature_template` SET `VehicleId` = 224 WHERE  `entry` = 31748;
UPDATE `creature_template` SET `VehicleId` = 223 WHERE  `entry` = 31749;
UPDATE `creature_template` SET `VehicleId` = 220 WHERE  `entry` = 31752;


--- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r14 r17 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r17');

UPDATE db_version SET `cache_id`= 'r17';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r17';