-- Eye of Kilrogg 
UPDATE `creature_template` SET `ScriptName` = 'npc_eye_of_kilrogg' WHERE `entry` = '4277';  

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r25 r26 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r26');

UPDATE db_version SET `cache_id`= 'r26';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r26';