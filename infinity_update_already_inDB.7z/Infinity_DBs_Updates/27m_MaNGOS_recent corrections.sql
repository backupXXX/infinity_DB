  -- Pet 26611 - shaman spirit wolf
DELETE FROM `pet_scaling_data` WHERE `creature_entry` = 29264;
INSERT INTO `pet_scaling_data` (`creature_entry`, `aura`, `healthbase`, `health`, `powerbase`, `power`, `str`, `agi`, `sta`, `inte`, `spi`, `armor`, `resistance1`, `resistance2`, `resistance3`, `resistance4`, `resistance5`, `resistance6`, `apbase`, `apbasescale`, `attackpower`, `damage`, `spelldamage`, `spellhit`, `hit`, `expertize`, `attackspeed`, `crit`, `regen`) VALUES
(29264,     0, 0, 1000, 0, 1500, 0, 0, 30, 0, 0, 35, 40, 40, 40, 40, 40, 40, 20, 200, 22, 0, 13, 100, 100, 100, 100, 0, 0),
(29264, 63271, 0,    0, 0,    0, 0, 0,  0, 0, 0,  0,  0,  0,  0,  0,  0,  0,  0,   0, 30, 0,  0,   0,   0,   0,   0, 0, 0);

UPDATE `creature_template` SET `vehicleId` = 531 WHERE `entry` IN (36598);

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r26 r27 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r27');

UPDATE db_version SET `cache_id`= 'r27';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r27';