-- fix quest 14142 
UPDATE `quest_template` SET `ReqSpellCast1` = '66531', `ReqSpellCast2` = '66531' WHERE `entry` =14142; 

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r31 r32 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r32');

UPDATE db_version SET `cache_id`= 'r32';
UPDATE db_version SET `version`= 'YTDB579_Infinity_Update_r32';