UPDATE `creature_template`
SET `PowerType` = 3, `spell1` = 62225, `spell2` = 47480, `spell3` = 47481, `spell4` = 47482, `spell5` = 47484, `spell6` = 67886,
`ScriptName` = 'npc_risen_ally'
WHERE `entry` = 30230;

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r23 r24 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r24');

UPDATE db_version SET `cache_id`= 'r24';
UPDATE db_version SET `version`= 'YTDB578_Infinity_Update_r24';