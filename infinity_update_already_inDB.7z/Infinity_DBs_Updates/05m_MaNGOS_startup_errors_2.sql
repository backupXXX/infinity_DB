-- all info on loot was take from www.wowhead.com  also i raid this place with just me and bots so i implent heroic gear into normal event
DELETE FROM `creature_loot_template` WHERE (`entry`=39747);
INSERT INTO `creature_loot_template` VALUES 
(39747, 33367, 11, 1, 1, 1, 0, 0, 0),
(39747, 36062, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36063, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36064, 4, 1, 1, 1, 0, 0, 0),
(39747, 36066, 3, 1, 1, 1, 0, 0, 0),
(39747, 36175, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36176, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36177, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36178, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36283, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36284, 3, 1, 1, 1, 0, 0, 0),
(39747, 36285, 4, 1, 1, 1, 0, 0, 0),
(39747, 36286, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36290, 11, 1, 1, 1, 0, 0, 0),
(39747, 36395, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36398, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36401, 6, 1, 1, 1, 0, 0, 0),
(39747, 36416, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36430, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36458, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 36668, 6, 1, 1, 1, 0, 0, 0),
(39747, 36682, 3, 1, 1, 1, 0, 0, 0),
(39747, 37781, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 38557, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 41777, 1.4, 1, 1, 1, 0, 0, 0),
(39747, 49426, 100, 0, 2, 2, 0, 0, 0),
(39747, 54588, 24, 2, 1, 1, 0, 0, 0),
(39747, 54589, 24, 2, 1, 1, 0, 0, 0),
(39747, 54590, 24, 2, 1, 1, 0, 0, 0),
(39747, 54591, 24, 2, 1, 1, 0, 0, 0);

DELETE FROM `creature_loot_template` WHERE (`entry`=39746);
INSERT INTO `creature_loot_template` VALUES 
(39746, 33412, 18, 1, 1, 1, 0, 0, 0),
(39746, 36059, 4, 1, 1, 1, 0, 0, 0),
(39746, 36060, 2, 1, 1, 1, 0, 0, 0),
(39746, 36061, 2, 1, 1, 1, 0, 0, 0),
(39746, 36063, 4, 1, 1, 1, 0, 0, 0),
(39746, 36171, 4, 1, 1, 1, 0, 0, 0),
(39746, 36177, 2, 1, 1, 1, 0, 0, 0),
(39746, 36283, 2, 1, 1, 1, 0, 0, 0),
(39746, 36397, 2, 1, 1, 1, 0, 0, 0),
(39746, 36398, 2, 1, 1, 1, 0, 0, 0),
(39746, 36401, 4, 1, 1, 1, 0, 0, 0),
(39746, 36402, 2, 1, 1, 1, 0, 0, 0),
(39746, 36444, 4, 1, 1, 1, 0, 0, 0),
(39746, 36528, 2, 1, 1, 1, 0, 0, 0),
(39746, 36598, 4, 1, 1, 1, 0, 0, 0),
(39746, 36682, 4, 1, 1, 1, 0, 0, 0),
(39746, 36696, 2, 1, 1, 1, 0, 0, 0),
(39746, 37761, 2, 1, 1, 1, 0, 0, 0),
(39746, 49426, 100, 0, 1, 1, 0, 0, 0),
(39746, 54588, 24, 2, 1, 1, 0, 0, 0),
(39746, 54589, 24, 2, 1, 1, 0, 0, 0),
(39746, 54590, 24, 2, 1, 1, 0, 0, 0),
(39746, 54591, 24, 2, 1, 1, 0, 0, 0);

DELETE FROM `creature_loot_template` WHERE (`entry`=39863);
INSERT INTO `creature_loot_template` VALUES 
(39863, 49426, 100, 0, 3, 3, 0, 0, 0),
(39863, 53103, 5, 1, 1, 1, 0, 0, 0),
(39863, 53110, 7, 1, 1, 1, 0, 0, 0),
(39863, 53111, 5, 1, 1, 1, 0, 0, 0),
(39863, 53112, 11, 1, 1, 1, 0, 0, 0),
(39863, 53113, 10, 1, 1, 1, 0, 0, 0),
(39863, 53114, 8, 1, 1, 1, 0, 0, 0),
(39863, 53115, 3, 1, 1, 1, 0, 0, 0),
(39863, 53116, 14, 1, 1, 1, 0, 0, 0),
(39863, 53117, 11, 1, 1, 1, 0, 0, 0),
(39863, 53118, 11, 1, 1, 1, 0, 0, 0),
(39863, 53119, 3, 1, 1, 1, 0, 0, 0),
(39863, 53121, 8, 1, 1, 1, 0, 0, 0),
(39863, 53125, 7, 2, 1, 1, 0, 0, 0),
(39863, 53126, 7, 2, 1, 1, 0, 0, 0),
(39863, 53127, 7, 2, 1, 1, 0, 0, 0),
(39863, 53129, 3, 2, 1, 1, 0, 0, 0),
(39863, 53132, 7, 2, 1, 1, 0, 0, 0),
(39863, 53133, 10, 4, 1, 1, 0, 0, 0),
(39863, 53134, 4, 2, 1, 1, 0, 0, 0),
(39863, 53486, 16, 2, 1, 1, 0, 0, 0),
(39863, 53487, 3, 2, 1, 1, 0, 0, 0),
(39863, 53488, 7, 2, 1, 1, 0, 0, 0),
(39863, 53489, 10, 2, 1, 1, 0, 0, 0),
(39863, 53490, 3, 2, 1, 1, 0, 0, 0),
(39863, 54556, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54557, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54558, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54559, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54561, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54562, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54563, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54564, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54565, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54567, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54569, 12, 4, 1, 1, 0, 0, 0),
(39863, 54571, 8, 4, 1, 1, 0, 0, 0),
(39863, 54572, 13, 2, 1, 1, 0, 0, 0),
(39863, 54573, 11, 2, 1, 1, 0, 0, 0),
(39863, 54576, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54577, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54578, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54580, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54581, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54582, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54583, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54584, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54585, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54587, 0.1, 3, 1, 1, 0, 0, 0),
(39863, 54588, 24, 5, 1, 1, 0, 0, 0),
(39863, 54589, 24, 5, 1, 1, 0, 0, 0),
(39863, 54590, 24, 5, 1, 1, 0, 0, 0),
(39863, 54591, 24, 5, 1, 1, 0, 0, 0);

DELETE FROM `creature_loot_template` WHERE (`entry`=39751);
INSERT INTO `creature_loot_template` VALUES 
(39751, 33366, 2, 1, 1, 1, 0, 0, 0),
(39751, 33416, 3, 1, 1, 1, 0, 0, 0),
(39751, 36059, 2, 1, 1, 1, 0, 0, 0),
(39751, 36062, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36064, 5, 1, 1, 1, 0, 0, 0),
(39751, 36171, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36173, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36176, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36177, 3, 1, 1, 1, 0, 0, 0),
(39751, 36283, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36284, 2, 1, 1, 1, 0, 0, 0),
(39751, 36285, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36286, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36289, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36399, 2, 1, 1, 1, 0, 0, 0),
(39751, 36400, 2, 1, 1, 1, 0, 0, 0),
(39751, 36430, 17, 1, 1, 1, 0, 0, 0),
(39751, 36444, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36556, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36584, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36598, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 36626, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 37771, 1.1, 1, 1, 1, 0, 0, 0),
(39751, 49426, 100, 0, 1, 1, 0, 0, 0),
(39751, 54588, 24, 2, 1, 1, 0, 0, 0),
(39751, 54589, 24, 2, 1, 1, 0, 0, 0),
(39751, 54590, 24, 2, 1, 1, 0, 0, 0),
(39751, 54591, 24, 2, 1, 1, 0, 0, 0);


-- special items made by notagain when he first implented RS

DELETE FROM `item_template` WHERE (`entry`=54588);
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `unk0`, `name`, `displayid`, `Quality`, `Flags`, `BuyCount`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `RequiredSkillRank`, `requiredspell`, `requiredhonorrank`, `RequiredCityRank`, `RequiredReputationFaction`, `RequiredReputationRank`, `maxcount`, `stackable`, `ContainerSlots`, `StatsCount`, `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, `stat_type5`, `stat_value5`, `stat_type6`, `stat_value6`, `stat_type7`, `stat_value7`, `stat_type8`, `stat_value8`, `stat_type9`, `stat_value9`, `stat_type10`, `stat_value10`, `ScalingStatDistribution`, `ScalingStatValue`, `dmg_min1`, `dmg_max1`, `dmg_type1`, `dmg_min2`, `dmg_max2`, `dmg_type2`, `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, `delay`, `ammo_type`, `RangedModRange`, `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, `spellcategory_1`, `spellcategorycooldown_1`, `spellid_2`, `spelltrigger_2`, `spellcharges_2`, `spellppmRate_2`, `spellcooldown_2`, `spellcategory_2`, `spellcategorycooldown_2`, `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, `spellcategory_3`, `spellcategorycooldown_3`, `spellid_4`, `spelltrigger_4`, `spellcharges_4`, `spellppmRate_4`, `spellcooldown_4`, `spellcategory_4`, `spellcategorycooldown_4`, `spellid_5`, `spelltrigger_5`, `spellcharges_5`, `spellppmRate_5`, `spellcooldown_5`, `spellcategory_5`, `spellcategorycooldown_5`, `bonding`, `description`, `PageText`, `LanguageID`, `PageMaterial`, `startquest`, `lockid`, `Material`, `sheath`, `RandomProperty`, `RandomSuffix`, `block`, `itemset`, `MaxDurability`, `area`, `Map`, `BagFamily`, `TotemCategory`, `socketColor_1`, `socketContent_1`, `socketColor_2`, `socketContent_2`, `socketColor_3`, `socketContent_3`, `socketBonus`, `GemProperties`, `RequiredDisenchantSkill`, `ArmorDamageModifier`, `Duration`, `ItemLimitCategory`, `HolidayId`, `ScriptName`, `DisenchantID`, `FoodType`, `minMoneyLoot`, `maxMoneyLoot`, `ExtraFlags`) VALUES (54588, 4, 0, -1, 'Chamber of Aspects 25 Heroic Nuker Trinket', 68106, 0, 0, 1, 0, 0, 12, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 75473, 0, 0, 1, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 'Made By Notagain', 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, '', 0, 0, 0, 0, 0);

DELETE FROM `item_template` WHERE (`entry`=54589);
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `unk0`, `name`, `displayid`, `Quality`, `Flags`, `BuyCount`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `RequiredSkillRank`, `requiredspell`, `requiredhonorrank`, `RequiredCityRank`, `RequiredReputationFaction`, `RequiredReputationRank`, `maxcount`, `stackable`, `ContainerSlots`, `StatsCount`, `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, `stat_type5`, `stat_value5`, `stat_type6`, `stat_value6`, `stat_type7`, `stat_value7`, `stat_type8`, `stat_value8`, `stat_type9`, `stat_value9`, `stat_type10`, `stat_value10`, `ScalingStatDistribution`, `ScalingStatValue`, `dmg_min1`, `dmg_max1`, `dmg_type1`, `dmg_min2`, `dmg_max2`, `dmg_type2`, `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, `delay`, `ammo_type`, `RangedModRange`, `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, `spellcategory_1`, `spellcategorycooldown_1`, `spellid_2`, `spelltrigger_2`, `spellcharges_2`, `spellppmRate_2`, `spellcooldown_2`, `spellcategory_2`, `spellcategorycooldown_2`, `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, `spellcategory_3`, `spellcategorycooldown_3`, `spellid_4`, `spelltrigger_4`, `spellcharges_4`, `spellppmRate_4`, `spellcooldown_4`, `spellcategory_4`, `spellcategorycooldown_4`, `spellid_5`, `spelltrigger_5`, `spellcharges_5`, `spellppmRate_5`, `spellcooldown_5`, `spellcategory_5`, `spellcategorycooldown_5`, `bonding`, `description`, `PageText`, `LanguageID`, `PageMaterial`, `startquest`, `lockid`, `Material`, `sheath`, `RandomProperty`, `RandomSuffix`, `block`, `itemset`, `MaxDurability`, `area`, `Map`, `BagFamily`, `TotemCategory`, `socketColor_1`, `socketContent_1`, `socketColor_2`, `socketContent_2`, `socketColor_3`, `socketContent_3`, `socketBonus`, `GemProperties`, `RequiredDisenchantSkill`, `ArmorDamageModifier`, `Duration`, `ItemLimitCategory`, `HolidayId`, `ScriptName`, `DisenchantID`, `FoodType`, `minMoneyLoot`, `maxMoneyLoot`, `ExtraFlags`) VALUES (54589, 4, 0, -1, 'Chamber of Aspects 25 Nuker Trinket', 68108, 0, 0, 1, 0, 0, 12, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 75466, 0, 0, 1, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 'Made By Notagain', 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, '', 0, 0, 0, 0, 0);

DELETE FROM `item_template` WHERE (`entry`=54590);
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `unk0`, `name`, `displayid`, `Quality`, `Flags`, `BuyCount`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `RequiredSkillRank`, `requiredspell`, `requiredhonorrank`, `RequiredCityRank`, `RequiredReputationFaction`, `RequiredReputationRank`, `maxcount`, `stackable`, `ContainerSlots`, `StatsCount`, `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, `stat_type5`, `stat_value5`, `stat_type6`, `stat_value6`, `stat_type7`, `stat_value7`, `stat_type8`, `stat_value8`, `stat_type9`, `stat_value9`, `stat_type10`, `stat_value10`, `ScalingStatDistribution`, `ScalingStatValue`, `dmg_min1`, `dmg_max1`, `dmg_type1`, `dmg_min2`, `dmg_max2`, `dmg_type2`, `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, `delay`, `ammo_type`, `RangedModRange`, `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, `spellcategory_1`, `spellcategorycooldown_1`, `spellid_2`, `spelltrigger_2`, `spellcharges_2`, `spellppmRate_2`, `spellcooldown_2`, `spellcategory_2`, `spellcategorycooldown_2`, `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, `spellcategory_3`, `spellcategorycooldown_3`, `spellid_4`, `spelltrigger_4`, `spellcharges_4`, `spellppmRate_4`, `spellcooldown_4`, `spellcategory_4`, `spellcategorycooldown_4`, `spellid_5`, `spelltrigger_5`, `spellcharges_5`, `spellppmRate_5`, `spellcooldown_5`, `spellcategory_5`, `spellcategorycooldown_5`, `bonding`, `description`, `PageText`, `LanguageID`, `PageMaterial`, `startquest`, `lockid`, `Material`, `sheath`, `RandomProperty`, `RandomSuffix`, `block`, `itemset`, `MaxDurability`, `area`, `Map`, `BagFamily`, `TotemCategory`, `socketColor_1`, `socketContent_1`, `socketColor_2`, `socketContent_2`, `socketColor_3`, `socketContent_3`, `socketBonus`, `GemProperties`, `RequiredDisenchantSkill`, `ArmorDamageModifier`, `Duration`, `ItemLimitCategory`, `HolidayId`, `ScriptName`, `DisenchantID`, `FoodType`, `minMoneyLoot`, `maxMoneyLoot`, `ExtraFlags`) VALUES (54590, 4, 0, -1, 'Chamber of Aspects 25 Heroic Melee Trinket', 68109, 0, 0, 1, 0, 0, 12, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 75458, 0, 0, 1, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 'Made By Notagain', 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, '', 0, 0, 0, 0, 0);

DELETE FROM `item_template` WHERE (`entry`=54591);
INSERT INTO `item_template` (`entry`, `class`, `subclass`, `unk0`, `name`, `displayid`, `Quality`, `Flags`, `BuyCount`, `BuyPrice`, `SellPrice`, `InventoryType`, `AllowableClass`, `AllowableRace`, `ItemLevel`, `RequiredLevel`, `RequiredSkill`, `RequiredSkillRank`, `requiredspell`, `requiredhonorrank`, `RequiredCityRank`, `RequiredReputationFaction`, `RequiredReputationRank`, `maxcount`, `stackable`, `ContainerSlots`, `StatsCount`, `stat_type1`, `stat_value1`, `stat_type2`, `stat_value2`, `stat_type3`, `stat_value3`, `stat_type4`, `stat_value4`, `stat_type5`, `stat_value5`, `stat_type6`, `stat_value6`, `stat_type7`, `stat_value7`, `stat_type8`, `stat_value8`, `stat_type9`, `stat_value9`, `stat_type10`, `stat_value10`, `ScalingStatDistribution`, `ScalingStatValue`, `dmg_min1`, `dmg_max1`, `dmg_type1`, `dmg_min2`, `dmg_max2`, `dmg_type2`, `armor`, `holy_res`, `fire_res`, `nature_res`, `frost_res`, `shadow_res`, `arcane_res`, `delay`, `ammo_type`, `RangedModRange`, `spellid_1`, `spelltrigger_1`, `spellcharges_1`, `spellppmRate_1`, `spellcooldown_1`, `spellcategory_1`, `spellcategorycooldown_1`, `spellid_2`, `spelltrigger_2`, `spellcharges_2`, `spellppmRate_2`, `spellcooldown_2`, `spellcategory_2`, `spellcategorycooldown_2`, `spellid_3`, `spelltrigger_3`, `spellcharges_3`, `spellppmRate_3`, `spellcooldown_3`, `spellcategory_3`, `spellcategorycooldown_3`, `spellid_4`, `spelltrigger_4`, `spellcharges_4`, `spellppmRate_4`, `spellcooldown_4`, `spellcategory_4`, `spellcategorycooldown_4`, `spellid_5`, `spelltrigger_5`, `spellcharges_5`, `spellppmRate_5`, `spellcooldown_5`, `spellcategory_5`, `spellcategorycooldown_5`, `bonding`, `description`, `PageText`, `LanguageID`, `PageMaterial`, `startquest`, `lockid`, `Material`, `sheath`, `RandomProperty`, `RandomSuffix`, `block`, `itemset`, `MaxDurability`, `area`, `Map`, `BagFamily`, `TotemCategory`, `socketColor_1`, `socketContent_1`, `socketColor_2`, `socketContent_2`, `socketColor_3`, `socketContent_3`, `socketBonus`, `GemProperties`, `RequiredDisenchantSkill`, `ArmorDamageModifier`, `Duration`, `ItemLimitCategory`, `HolidayId`, `ScriptName`, `DisenchantID`, `FoodType`, `minMoneyLoot`, `maxMoneyLoot`, `ExtraFlags`) VALUES (54591, 4, 0, -1, 'Chamber of Aspects 25 Melee Trinket', 68107, 0, 0, 1, 0, 0, 12, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 75456, 0, 0, 1, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, -1, 0, -1, 0, 'Made By Notagain', 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, '', 0, 0, 0, 0, 0);
-- Start errors make sure you run this after all of SD2
DELETE FROM `reference_loot_template` WHERE (`entry`='40630' AND `item`='40630') OR (`entry`='40630' AND `item`='40629') OR (`entry`='40630' AND `item`='40628');
DELETE FROM `creature_template` WHERE (`entry`=2);
UPDATE `creature_template` SET `minmana` = 0, `maxmana` = 10000 WHERE `entry` = 26861;

--- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r04 r05 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r05');

UPDATE db_version SET `cache_id`= 'r05';
UPDATE db_version SET `version`= 'YTDB572_Infinity_Update_r05';