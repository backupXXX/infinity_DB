-- Quest: Plagued Lands (2118)
UPDATE creature_template SET ScriptName='npc_rabid_bear' WHERE entry=2164;

-- FallenAngelX
ALTER TABLE db_version_Infinity_Update CHANGE COLUMN r28 r29 bit;
REPLACE INTO `db_version_Infinity_Update` (`version`) VALUES ('r29');

UPDATE db_version SET `cache_id`= 'r29';
UPDATE db_version SET `version`= 'YTDB579_Infinity_Update_r29';