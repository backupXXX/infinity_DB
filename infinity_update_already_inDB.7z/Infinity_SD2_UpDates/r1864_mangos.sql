UPDATE creature_template SET ScriptName='npc_silvermoon_harry' WHERE entry=24539;
