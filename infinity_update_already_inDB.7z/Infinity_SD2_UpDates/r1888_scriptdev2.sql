DELETE FROM script_texts WHERE entry=-1000625;
INSERT INTO script_texts (entry,content_default,sound,type,language,emote,comment) VALUES
(-1000625,'%s gathers the warp chaser\'s blood.',0,2,0,0,'zeppit EMOTE_GATHER_BLOOD');
