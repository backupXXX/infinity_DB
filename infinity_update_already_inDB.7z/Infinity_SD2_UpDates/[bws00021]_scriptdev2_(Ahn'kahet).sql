-- -- CUSTOM -----

DELETE FROM script_texts WHERE entry IN (-1619041, -1619040, -1619042);
INSERT INTO `script_texts` (`entry`, `content_default`, `content_loc1`, `content_loc2`, `content_loc3`, `content_loc4`, `content_loc5`, `content_loc6`, `content_loc7`, `content_loc8`, `sound`, `type`, `language`, `emote`, `comment`) VALUES
('-1619041', 'Ancient Voidwalker is being Corrupted!', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '3', '0', '0', 'Ancient Voidwalker - custom text'),
('-1619042', 'Feel the power of old Gods!', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '0', '0', 'Ancient Voidwalker - custom text'),
('-1619040', 'Not even creations of Old Gods can not face anger of the Yogg-Saron!', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '0', '0', 'Herald Volazj - custom text');

-- - END CUSTOM --