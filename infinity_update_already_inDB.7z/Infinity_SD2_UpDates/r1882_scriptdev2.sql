DELETE FROM gossip_texts WHERE entry=-3000105;
INSERT INTO gossip_texts (entry,content_default,comment) VALUES
(-3000105,'Ezekiel said that you might have a certain book...','dirty larry GOSSIP_ITEM_BOOK');
