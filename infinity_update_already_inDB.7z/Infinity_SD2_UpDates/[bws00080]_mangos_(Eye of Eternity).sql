UPDATE instance_template SET scriptname='instance_eye_of_eternity' where map=616;
UPDATE gameobject_template SET ScriptName='go_focusing_iris' WHERE entry IN (193958, 193960);
UPDATE creature_template SET ScriptName='boss_malygos' WHERE entry=28859;
UPDATE creature_template SET ScriptName='npc_power_spark' WHERE entry=30084;
UPDATE creature_template SET ScriptName='npc_nexus_lord' WHERE entry=30245;
UPDATE creature_template SET ScriptName='npc_scion_of_eternity' WHERE entry=30249;
UPDATE creature_template SET ScriptName='npc_hover_disk' WHERE entry=30248;
UPDATE creature_template SET ScriptName='npc_alexstrasza' WHERE entry=32295;


-- vehicle data for Hover Disks and Wyrmrest Skytalons (normal and heroic)
UPDATE creature_template SET VehicleId=220, Spell1=56091, Spell2=56092, Spell3=57090, Spell4=57143, Spell5=57108, Spell6=57092 WHERE entry IN (30161, 31752);

UPDATE creature_template SET VehicleId=223 WHERE entry IN (30248, 31749);

DELETE FROM npc_spellclick_spells WHERE npc_entry=30248;
INSERT INTO npc_spellclick_spells (npc_entry, spell_id, quest_start, quest_start_active, quest_end, cast_flags) VALUES
(30248, 48754, 0, 0, 0, 1);
