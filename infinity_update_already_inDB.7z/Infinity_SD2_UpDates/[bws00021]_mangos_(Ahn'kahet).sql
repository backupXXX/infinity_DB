UPDATE creature_template SET ScriptName='npc_amanitar_mushroom' WHERE entry IN (30391, 30435);
UPDATE creature_template SET ScriptName='boss_amanitar' WHERE entry = 30258;
UPDATE creature_template SET ScriptName='mob_flame_orb' WHERE entry=30702;
UPDATE creature_template SET ScriptName='npc_twilight_volunteer' WHERE entry=30385;
UPDATE creature_template SET ScriptName='mob_twisted_visage' WHERE entry=30621;
UPDATE creature_template SET ScriptName='mob_ancient_void' WHERE entry=30622;