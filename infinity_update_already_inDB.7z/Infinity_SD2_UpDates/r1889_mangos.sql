UPDATE creature_template SET ScriptName='npc_depleted_war_golem' WHERE entry=27017;
